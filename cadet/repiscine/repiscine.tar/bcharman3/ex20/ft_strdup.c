/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bcharman <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/02/06 19:56:30 by bcharman          #+#    #+#             */
/*   Updated: 2019/04/07 16:55:16 by bcharman         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

char	*ft_strdup(char *src)
{
	int		i;
	int		n;
	char	*s;

	i = -1;
	n = 0;
	while (src[++i])
		n++;
	s = malloc(n * sizeof(char));
	i = -1;
	while (src[++i])
		s[i] = src[i];
	return (s);
}

int		main()
{
	char *s1 = "O4hcFIPKaXnhew8f4W";
	char *s2;
	s2 = ft_strdup(s1);
	printf("%s\n", s1);
	printf("%s\n", s2);
	return 0;
}
